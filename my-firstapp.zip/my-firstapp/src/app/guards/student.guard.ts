import { CanActivateFn, Router, RouterEvent } from '@angular/router';
import {inject} from '@angular/core'
export const studentGuard: CanActivateFn = (route, state) => {
  let routes = inject(Router)
  let user= JSON.parse(localStorage['current_user'])
  if(!user){
    routes.navigate(['/signin'])
  }
  return true
};
