import { Injectable } from '@angular/core';
import { LandingpageserviceService } from './landingpageservice.service';

@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {

  constructor() { }
}
