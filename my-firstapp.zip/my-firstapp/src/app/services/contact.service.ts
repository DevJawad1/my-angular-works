import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  constructor() { }

  public getContact=JSON.parse(localStorage['contactDetails'])

  infoHolder(){
   return this.getContact 
  }
}
