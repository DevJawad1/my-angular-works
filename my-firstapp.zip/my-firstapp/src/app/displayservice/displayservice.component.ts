import { Component } from '@angular/core';
import { ContactService } from '../services/contact.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-displayservice',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './displayservice.component.html',
  styleUrl: './displayservice.component.css'
})
export class DisplayserviceComponent {
  constructor(public information:ContactService){}
  public getInfo:any=""
  ngOnInit(){
    // this.getInfo(this) 
    this.getInfo=this.information.infoHolder()
    console.log(this.getInfo);
  }
  delet(i:any){

  }
  edit(i:number){

  }
}
