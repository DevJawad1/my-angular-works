import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { log } from 'node:console';
import { ContactService } from '../services/contact.service';

@Component({
  selector: 'app-editcontact',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './editcontact.component.html',
  styleUrl: './editcontact.component.css'
})
export class EditcontactComponent {
  constructor (public activated:ActivatedRoute, public router:Router, public infoGet:ContactService){}
  public eachContact:any =''
  public editCont='hidden'
  public getcontact:any=this.infoGet.infoHolder()
  public id=this.activated.snapshot.params['id']
  ngOnInit(){
    this.eachContact=this.getcontact[this.id] 
  }
  delet(i:number){
    this.getcontact=this.getcontact.filter((item:any, id:any)=> i!=id)
    localStorage.setItem('contactDetails', JSON.stringify(this.getcontact))
    this.router.navigate(['dashboard'])
  }

  public firstname=''
  public lastname=''
  public email=''
  public address=''
  public gender=''
  edit(i:number){
    this.editCont='visible'
  }
  save(i: number) {
    let contactObj = {
      firstname: this.firstname,
      lastname: this.lastname,
      email: this.email,
      gender: this.gender,
      address: this.address,
    }
    this.getcontact.splice(i, 1, contactObj);
    localStorage.setItem('contactDetails', JSON.stringify(this.getcontact));
    this.editCont = 'hidden';
    let id = this.activated.snapshot.params['id'];
    this.eachContact = this.getcontact[id]
  }
}
