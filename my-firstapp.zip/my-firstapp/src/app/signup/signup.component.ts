import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TopNavBarComponent } from '../top-nav-bar/top-nav-bar.component';

interface detailsInterface{
  Firstname:string,
  Lastname:string,
  Email:string,
  Gender:string,
  Password:string,
}
@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule, TopNavBarComponent],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent {
  constructor(public route:Router){}
  public firstname=""
  public lastname=""
  public email =""
  public gender=""
  public password=""
  public allUser:detailsInterface[]=[]
  message=""
  submit(){
    if(localStorage['Holderuser']){
      let getUser=JSON.parse(localStorage['Holderuser'])
      this.allUser=getUser
    }
    let userobj={
      Firstname:this.firstname,
      Lastname:this.lastname,
      Email:this.email,
      Gender:this.gender,
      Password:this.password
    }
    this.allUser.push(userobj)
    localStorage.setItem('Holderuser', JSON.stringify(this.allUser))
    if(this.allUser.push(userobj)){
      this.route.navigate(['/signin'])
    }
    else{
      this.message="Cant sign up error"
    }
  }
}
