import { Component } from '@angular/core';

@Component({
  selector: 'app-deletcontact',
  standalone: true,
  imports: [],
  templateUrl: './deletcontact.component.html',
  styleUrl: './deletcontact.component.css'
})
export class DeletcontactComponent {

}
