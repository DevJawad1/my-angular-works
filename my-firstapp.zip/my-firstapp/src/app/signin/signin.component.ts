import { Component } from '@angular/core';
import { TopNavBarComponent } from '../top-nav-bar/top-nav-bar.component';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
interface detailsInterface{
  Firstname:string,
  Lastname:string,
  Email:string,
  Gender:string,
  Password:string,
}
@Component({
  selector: 'app-signin',
  standalone: true,
  imports: [TopNavBarComponent, FormsModule,CommonModule],
  templateUrl: './signin.component.html',
  styleUrl: './signin.component.css'
})
export class SigninComponent {
 constructor(public router:Router){}
 public message=""
 public email=""
 public password=""
 public inpclass=""
 public inpclass2=""
 public getUser:detailsInterface[]=[]
  ngOnInit(){
    this.getUser=JSON.parse(localStorage['Holderuser'])
  }
  login(){
    let currentUser=this.getUser.find((item, index)=>this.email==item.Email && this.password==item.Password)
    console.log(currentUser);
    if(currentUser){
      this.message="User found"
      localStorage.setItem('current_user', JSON.stringify(currentUser))
      setTimeout(() => {
        this.message=""
        this.router.navigate(['dashboard'])
      }, 1300);
    }
    else{
      this.message="User not found"
      setTimeout(() => {
        this.message=""
      }, 2000);
    }
  }
  inp1(){
    this.inpclass='em'
    this.inpclass2=''
  }
  inp2(){
    this.inpclass=''
    this.inpclass2='em'
  }
}
