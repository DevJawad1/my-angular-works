import { Routes } from '@angular/router';
import { FirstWorkComponent } from './first-work/first-work.component';
import path from 'path';
import { DisplaucontactComponent } from './displaucontact/displaucontact.component';
import { EditcontactComponent } from './editcontact/editcontact.component';
import { ErrorpageComponent } from './errorpage/errorpage.component';
import { ServicecomponentComponent } from './servicecomponent/servicecomponent.component';
import { DisplayserviceComponent } from './displayservice/displayservice.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SignupComponent } from './signup/signup.component';
import { SigninComponent } from './signin/signin.component';
import { AdminComponent } from './admin/admin.component';
import { studentGuard } from './guards/student.guard';

export const routes: Routes = [
  {path:'', component:FirstWorkComponent},
  {path:'home', redirectTo:'', pathMatch:'full'},
  {path:'service', component:ServicecomponentComponent},
  {path:"Contacserve", component:DisplayserviceComponent},
  {path:"dashboard", children:[
    {path:'', component:DashboardComponent},
    {path:'admin', component:AdminComponent},
  ],canActivate:[studentGuard]},
  {path:"signup", component:SignupComponent},
  {path:"signin", component:SigninComponent},
  {path:'list', children:[
    {path:'', component:DisplaucontactComponent},
    {path:'view/:id', component:EditcontactComponent},
  ]},
  // {path:'display/:index', component:DisplaucontactComponent},
  {path:'**', component:ErrorpageComponent}
];
